package bot

import (
	"strings"
	"testing"

	tele "gopkg.in/telebot.v3"
)

func TestRenderMessageTemplateMarkdownV2MixesStructuralAndPlainVars(t *testing.T) {
	rendered := RenderMessageTemplate(
		"欢迎 {user} 来到 *{group}* [说明](https://example.com/path?a=1) (_提示_)",
		"markdownv2",
		map[string]string{
			"{user}": "[可乐](tg://user?id=42)",
		},
		map[string]string{
			"{group}": "高级群[一](测试)",
		},
	)

	if rendered.ParseMode != tele.ModeMarkdownV2 {
		t.Fatalf("parse mode = %q, want %q", rendered.ParseMode, tele.ModeMarkdownV2)
	}
	if !strings.Contains(rendered.Text, "[可乐](tg://user?id=42)") {
		t.Fatalf("structural var was escaped or lost: %q", rendered.Text)
	}
	if !strings.Contains(rendered.Text, "*高级群\\[一\\]\\(测试\\)*") {
		t.Fatalf("plain var was not escaped in MarkdownV2: %q", rendered.Text)
	}
	if !strings.Contains(rendered.Text, "[说明](https://example.com/path?a=1)") {
		t.Fatalf("existing markdown link should be preserved: %q", rendered.Text)
	}
	if !strings.Contains(rendered.Text, "(_提示_)") {
		t.Fatalf("existing markdown italic syntax should be preserved: %q", rendered.Text)
	}
}

func TestRenderMessageTemplateHTMLKeepsTemplateTagsAndEscapesPlainVars(t *testing.T) {
	rendered := RenderMessageTemplate(
		"<b>欢迎</b> {user_mention} <i>{group}</i> <code>{reason}</code>",
		"html",
		map[string]string{
			"{user_mention}": `<a href="tg://user?id=42">可乐</a>`,
		},
		map[string]string{
			"{group}":  `群组 <测试>`,
			"{reason}": `bad <b>tag</b> & more`,
		},
	)

	if rendered.ParseMode != tele.ModeHTML {
		t.Fatalf("parse mode = %q, want %q", rendered.ParseMode, tele.ModeHTML)
	}
	if !strings.Contains(rendered.Text, "<b>欢迎</b>") {
		t.Fatalf("template HTML tags should be preserved: %q", rendered.Text)
	}
	if !strings.Contains(rendered.Text, `<a href="tg://user?id=42">可乐</a>`) {
		t.Fatalf("structural HTML var should be preserved: %q", rendered.Text)
	}
	if !strings.Contains(rendered.Text, "群组 &lt;测试&gt;") {
		t.Fatalf("plain HTML var should be escaped: %q", rendered.Text)
	}
	if !strings.Contains(rendered.Text, "bad &lt;b&gt;tag&lt;/b&gt; &amp; more") {
		t.Fatalf("plain HTML var should escape tags and ampersands: %q", rendered.Text)
	}
}

func TestRenderMessageTemplateMarkdownLegacyLeavesTemplateAndVarsRaw(t *testing.T) {
	rendered := RenderMessageTemplate(
		"*欢迎* {user} [群](link): {reason}",
		"markdown",
		map[string]string{
			"{user}": "@kele",
		},
		map[string]string{
			"{reason}": "<b>[test](x)</b>",
		},
	)

	if rendered.ParseMode != tele.ModeMarkdown {
		t.Fatalf("parse mode = %q, want %q", rendered.ParseMode, tele.ModeMarkdown)
	}
	if rendered.Text != "*欢迎* @kele [群](link): <b>[test](x)</b>" {
		t.Fatalf("legacy markdown should remain raw, got %q", rendered.Text)
	}
}

func TestRenderMessageTemplateDefaultsUnknownToMarkdownV2(t *testing.T) {
	rendered := RenderMessageTemplate(
		"Hi {name}",
		"",
		nil,
		map[string]string{
			"{name}": "A[B](C)!",
		},
	)

	if rendered.ParseMode != tele.ModeMarkdownV2 {
		t.Fatalf("parse mode = %q, want %q", rendered.ParseMode, tele.ModeMarkdownV2)
	}
	if rendered.Text != "Hi A\\[B\\]\\(C\\)\\!" {
		t.Fatalf("unexpected MarkdownV2 default render: %q", rendered.Text)
	}
}

func TestRenderMessageTemplateMarkdownV2RealWorldChineseTemplate(t *testing.T) {
	template := `加入 *高级用户群* 即可享受：
⚡ 秒级工单响应
🎁 专属高级群福利
📥 *如需了解加入方式，请发送：*
👉 ` + "`高级群怎么进`"

	rendered := RenderMessageTemplate(template, "markdownv2", nil, nil)

	if rendered.ParseMode != tele.ModeMarkdownV2 {
		t.Fatalf("parse mode = %q, want %q", rendered.ParseMode, tele.ModeMarkdownV2)
	}
	if !strings.Contains(rendered.Text, "*高级用户群*") {
		t.Fatalf("bold syntax should be preserved: %q", rendered.Text)
	}
	if !strings.Contains(rendered.Text, "*如需了解加入方式，请发送：*") {
		t.Fatalf("bold syntax before fullwidth colon should be preserved: %q", rendered.Text)
	}
	if !strings.Contains(rendered.Text, "`高级群怎么进`") {
		t.Fatalf("code syntax should be preserved: %q", rendered.Text)
	}
}
